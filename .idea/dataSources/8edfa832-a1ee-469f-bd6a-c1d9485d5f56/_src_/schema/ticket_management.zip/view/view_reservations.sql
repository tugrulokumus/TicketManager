CREATE VIEW `view_reservations` AS
  SELECT
    `ticket_management`.`activities`.`name`           AS `name`,
    `ticket_management`.`users`.`UserName`            AS `username`,
    `ticket_management`.`reservations`.`ticket_count` AS `ticket_count`
  FROM ((`ticket_management`.`activities`
    JOIN `ticket_management`.`reservations`
      ON ((`ticket_management`.`activities`.`ID` = `ticket_management`.`reservations`.`activity_id`))) JOIN
    `ticket_management`.`users` ON ((`ticket_management`.`users`.`ID` = `ticket_management`.`reservations`.`user_id`)))